#!/bin/sh

SHFILE=/etc/mdev/${MDEV}.sh
if [ -e ${SHFILE} ]; then
	/bin/sh ${SHFILE}
fi
